<?php
Yii::setAlias('photo', "uploads/ads");
